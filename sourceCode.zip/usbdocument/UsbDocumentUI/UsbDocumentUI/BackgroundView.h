//
//  BackgroundView.h
//  UsbDocumentUI
//
//  Created by AldoIlsant on 14/11/15.
//  Copyright © 2015 aldoilsant. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface BackgroundView : NSView

@end
